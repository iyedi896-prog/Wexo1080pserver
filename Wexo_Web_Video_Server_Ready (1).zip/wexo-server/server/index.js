'use strict';
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const ffmpeg = require('fluent-ffmpeg');
const ffmpegPath = require('ffmpeg-static');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

if (!ffmpegPath) throw new Error('ffmpeg-static binary is not available for this platform');
ffmpeg.setFfmpegPath(ffmpegPath);
const app = express();
const PORT = Number(process.env.PORT || 3000);
const MAX_FILE_MB = Math.min(500, Math.max(10, Number(process.env.MAX_FILE_MB || 500)));
const allowedOrigins = (process.env.ALLOWED_ORIGINS || '*').split(',').map(x => x.trim()).filter(Boolean);
const tempRoot = path.join(os.tmpdir(), 'wexo-processing');
fs.mkdirSync(tempRoot, { recursive: true });

app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin(origin, cb) {
  if (!origin || allowedOrigins.includes('*') || allowedOrigins.includes(origin)) return cb(null, true);
  return cb(new Error('Origin is not allowed'), false);
}, exposedHeaders: ['Content-Disposition', 'X-Wexo-Mode'] }));
app.use(express.static(path.join(__dirname, '..', 'public'), { maxAge: '1h' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 12, standardHeaders: true, legacyHeaders: false }));
const upload = multer({
  dest: tempRoot,
  limits: { fileSize: MAX_FILE_MB * 1024 * 1024, files: 1 },
  fileFilter(_req, file, cb) {
    const ext = path.extname(file.originalname || '').toLowerCase();
    const ok = ['.mp4', '.mov', '.m4v', '.webm', '.mkv'].includes(ext) || /^video\//i.test(file.mimetype || '');
    cb(ok ? null : new Error('Upload a supported video file.'), ok);
  }
});

function safeName(name) {
  const base = path.basename(name || 'wexo-video.mp4').replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 100);
  return base || 'wexo-video.mp4';
}
function ffprobe(file) {
  return new Promise((resolve, reject) => ffmpeg.ffprobe(file, (err, data) => err ? reject(err) : resolve(data)));
}
function runFfmpeg(input, output, args) {
  return new Promise((resolve, reject) => {
    let command = ffmpeg(input);
    for (const arg of args) command = command.outputOptions(arg);
    command.on('end', resolve).on('error', reject).save(output);
  });
}
function removeQuietly(file) { try { if (file && fs.existsSync(file)) fs.unlinkSync(file); } catch (_) {} }

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'wexo-video-processing', version: '1.0.0', modes: ['originalHD', 'real1080', 'timeBooster'] }));

app.post('/api/process', upload.single('video'), async (req, res) => {
  const source = req.file && req.file.path;
  if (!source) return res.status(400).json({ error: 'Missing video file. Send multipart field named video.' });
  const mode = String(req.body.mode || 'originalHD');
  const allowedModes = new Set(['originalHD', 'real1080', 'timeBooster']);
  if (!allowedModes.has(mode)) { removeQuietly(source); return res.status(400).json({ error: 'Unsupported processing mode.' }); }
  const id = crypto.randomUUID();
  const ext = mode === 'originalHD' ? path.extname(req.file.originalname || '') || '.mp4' : '.mp4';
  const output = path.join(tempRoot, `${id}${ext}`);
  let finished = false;
  const cleanup = () => { removeQuietly(source); removeQuietly(output); };
  res.on('close', () => { if (!finished) cleanup(); });
  try {
    const probe = await ffprobe(source);
    const video = (probe.streams || []).find(s => s.codec_type === 'video');
    if (!video) throw new Error('The uploaded file does not contain a video stream.');
    if (mode === 'originalHD') {
      // Preserve source bytes: no re-encoding or metadata rewrite.
      finished = true;
      res.setHeader('Content-Type', req.file.mimetype || 'application/octet-stream');
      res.setHeader('Content-Disposition', `attachment; filename="${safeName(req.file.originalname)}"`);
      res.setHeader('X-Wexo-Mode', mode);
      return res.sendFile(source, err => { removeQuietly(source); if (err && !res.headersSent) res.status(500).end(); });
    }
    if (mode === 'real1080') {
      // Scale to 1920x1080 without stretching; pad if source aspect ratio differs.
      // Force 60 fps: this preserves 60fps sources; sources above 60fps are sampled down.
      await runFfmpeg(source, output, [
        '-vf', 'scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=60',
        '-c:v libx264', '-preset veryfast', '-crf 18', '-pix_fmt yuv420p',
        '-c:a aac', '-b:a 192k', '-movflags +faststart', '-map_metadata 0'
      ]);
    } else {
      // Double duration by playing the video at half speed. Audio is slowed in sync.
      // This does not invent detail or create 240 unique frames per second.
      const audio = (probe.streams || []).some(s => s.codec_type === 'audio');
      const opts = ['-vf setpts=2*PTS', '-r 30', '-c:v libx264', '-preset veryfast', '-crf 18', '-pix_fmt yuv420p'];
      if (audio) opts.push('-af atempo=0.5', '-c:a aac', '-b:a 192k');
      else opts.push('-an');
      opts.push('-movflags +faststart', '-map_metadata 0');
      await runFfmpeg(source, output, opts);
    }
    const resultProbe = await ffprobe(output);
    const resultVideo = (resultProbe.streams || []).find(s => s.codec_type === 'video');
    if (!resultVideo) throw new Error('Processing did not produce a valid video stream.');
    finished = true;
    res.setHeader('Content-Type', 'video/mp4');
    res.setHeader('Content-Disposition', `attachment; filename="${safeName(path.parse(req.file.originalname).name)}-${mode}.mp4"`);
    res.setHeader('X-Wexo-Mode', mode);
    res.setHeader('X-Wexo-Width', String(resultVideo.width || ''));
    res.setHeader('X-Wexo-Height', String(resultVideo.height || ''));
    res.setHeader('X-Wexo-FPS', String(resultVideo.avg_frame_rate || resultVideo.r_frame_rate || ''));
    res.setHeader('X-Wexo-Duration', String(resultProbe.format && resultProbe.format.duration || ''));
    res.sendFile(output, err => { cleanup(); if (err && !res.headersSent) res.status(500).end(); });
  } catch (err) {
    cleanup();
    console.error('[wexo-process]', err && err.message || err);
    if (!res.headersSent) res.status(422).json({ error: 'Video processing failed. Try an MP4/MOV file supported by FFmpeg.', details: String(err.message || 'Unknown error').slice(0, 240) });
  }
});

app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError && err.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: `Video exceeds the ${MAX_FILE_MB} MB upload limit.` });
  if (err) return res.status(400).json({ error: String(err.message || 'Invalid request').slice(0, 200) });
  return res.status(500).json({ error: 'Unexpected server error.' });
});
app.listen(PORT, '0.0.0.0', () => console.log(`Wexo video API listening on ${PORT}`));
